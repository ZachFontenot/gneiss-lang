let var = "string";;
var
